create trigger update_time_resourcelist
  before UPDATE
  on tb_resourcelist
  for each row
  set new.resourcelist_utime = now();

